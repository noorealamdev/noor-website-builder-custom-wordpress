<?php

/**
 * Class WPML_OT_Progress_Bars
 */
class WPML_OT_Progress_Bars extends WPML_Elementor_Module_With_Items  {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'noor_progress';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return array( 'title', 'desc_text' );
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch( $field ) {
			case 'title':
				return esc_html__( 'Title', 'noor' );

			case 'desc_text':
				return esc_html__( 'Description', 'noor' );

			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch( $field ) {
			
			case 'title':
				return 'LINE';

			case 'desc_text':
				return 'AREA';

			default:
				return '';
		}
	}

}
