<?php
use Elementor\Controls_Stack;
use Elementor\Controls_Manager;
use Elementor\Element_Column;
use Elementor\Core\Base\Module;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Ot_Noor_Effect extends Module {

	public function __construct() {

		$this->add_actions();
	}

	public function get_name() {
		return 'noor-effect';
	}

	/**
	 * @param $element
	 */
	public function register_controls( $element ) {

		$element->start_controls_section(
			'noor_ani_effect',
			[
				'label' => __( 'Noor Effects', 'noor' ),
				'tab'   => Controls_Manager::TAB_ADVANCED,
			]
		);

		$element->add_control(
			'noor_ani_name',
			[
				'label'     => __( 'Animation Name', 'noor' ),
				'type'      => Controls_Manager::SELECT2,
				'default'   => '',
				'label_block' => true,
				'render_type' => 'template',
				'options'   => [
					''					=> __( 'Default', 'noor' ),
					'sbFadeIn'          => __( 'Fade In', 'noor' ),
					'sbSlideInLeft'     => __( 'Slide In Left', 'noor' ),
					'sbSlideInRight'    => __( 'Slide In Right', 'noor' ),
					'sbSlideInDown'     => __( 'Slide In Down', 'noor' ),
					'sbSlideInUp'       => __( 'Slide In Up', 'noor' ),
					'sbZoomIn'          => __( 'Zoom In', 'noor' ),
					'sbZoomOut'         => __( 'Zoom Out', 'noor' ),
					'sbRotateIn'    	=> __( 'Rotate In', 'noor' ),
					'sbBounceIn'   		=> __( 'Bounce In', 'noor' ),
					'sbBounceInLeft' 	=> __( 'Bounce In Left', 'noor' ),
					'sbBounceInRight' 	=> __( 'Bounce In Right', 'noor' ),
					'sbBounceInDown' 	=> __( 'Bounce In Down', 'noor' ),
					'sbBounceInUp' 		=> __( 'Bounce In Up', 'noor' ),
					'sbFlipInX' 		=> __( 'Flip In X', 'noor' ),
					'sbFlipInY' 		=> __( 'Flip In Y', 'noor' ),
				],
			]
		);
		$element->add_control(
			'noor_ani_duration',
			[
				'label'     => __( 'Animation Duration (ms)', 'noor' ),
				'type'      => Controls_Manager::NUMBER,
				'min' => 100,
				'max' => 10000,
				'step' => 50,
				'default' => 700,
				'condition' => [
					'noor_ani_name!'     => '',
				],
			]
		);

		$element->add_control(
			'noor_ani_delay',
			[
				'label'     => __( 'Animation Delay (ms)', 'noor' ),
				'type'      => Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 10000,
				'step' => 50,
				'default' => 300,
				'condition' => [
					'noor_ani_name!'     => '',
				],

			]
		);

		$element->end_controls_section();
	}

	/**
	 * Render Noor Effects output on the frontend.
	 *
	 * Written in PHP and used to collect cursor settings and add it as an element attribute.
	 *
	 * @access public
	 * @param object $element for current element.
	 */
	public function before_render( $element ) {
		$data = $element->get_data();

		$type = $data['elType'];

		$settings = $element->get_settings_for_display();

		if ( 'widget' === $type && ! empty( $settings['noor_ani_name'] ) ) {
			
			$element->add_render_attribute( '_wrapper', 'data-cue', $settings['noor_ani_name'] );
			if( !empty($settings['noor_ani_duration']) ){
				$element->add_render_attribute( '_wrapper', 'data-duration', $settings['noor_ani_duration'] );
			}
			if( !empty($settings['noor_ani_delay']) ){
				$element->add_render_attribute( '_wrapper', 'data-delay', $settings['noor_ani_delay'] );
			}
		}
	}

	protected function add_actions() {
		// Creates Noor Effects tab at the end of advanced tab.
		add_action( 'elementor/element/common/_section_style/after_section_end', [ $this, 'register_controls' ], 10 );
		// Insert data before widget rendering.
		add_action( 'elementor/frontend/widget/before_render', [ $this, 'before_render' ] );
	}
}

new Ot_Noor_Effect();
