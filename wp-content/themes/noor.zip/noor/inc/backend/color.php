<?php 
//Custom Style Frontend
if(!function_exists('noor_color_scheme')){
    function noor_color_scheme(){
        $color_scheme = '';

        //Main Color
        if( !empty( noor_get_option('main_color') ) && noor_get_option('main_color') != '#3f78e0' ){
            $color_scheme = 
            '
            :root {
                --noor-color-primary: '.noor_get_option('main_color').';
            }
            .octf-btn{
                --noor-btn-bg: '.noor_get_option('main_color').';
            }

			';
        }

        if(! empty($color_scheme)){
			echo '<style>'.$color_scheme.'</style>';
		}
    }
}
add_action('wp_head', 'noor_color_scheme');